import CTABanner from "./section/cta-banner/cta-banner";
import HeroBanner from "./section/hero-banner/hero-banner";

export default function LandingPage() {
  return <>
    <HeroBanner image="/HeroBannerImage.png" />
    <CTABanner />
  </>;
}
