import React from "react";
import styles from "./hero-banner.module.css";
import GradientContainer from "../../../../component/GradientContainer/GradientContainer";
import FilledActionButton from "../../../../component/FilledActionButton/FilledActionButton";

interface HeroBannerProps {
  image: string;
}

const HeroBanner: React.FC<HeroBannerProps> = ({ image }) => {
  return (
    <GradientContainer>

      <section className={styles.hero}>

        <div className={styles.content}>

          <h4 className={styles.subtitle}>Personal loans from</h4>
          <h1 className={styles.title}>Top Banks, <br /> All in one place.</h1>

          <ul className={styles.list}>
            <li>✅ Rates from 5.20% - 35.99% APR1</li>
            <li>✅ Loan amounts from $600 to $200,000</li>
          </ul>

          <div className={styles.clientsAndButton}>
            
            <FilledActionButton text="Loan Now!" onClick={()=>{}} />

            <span className={styles.clientText}>
              50,000+ clients around the world
            </span>
          </div>

        </div>

        <div className={styles.imageWrapper}>
          <img src={image} alt="Hero" className={styles.image} />
        
        </div>
      </section>
    </GradientContainer>
  );
};

export default HeroBanner;
