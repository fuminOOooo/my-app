import React from "react";
import styles from "./cta-banner.module.css";
import InfoCard from "../../../../component/InfoCard/InfoCard";
import GradientContainer from "../../../../component/GradientContainer/GradientContainer";

const CTABanner = () => {
  return (
    <GradientContainer>
      <section className={styles.section}>

        <p className={styles.subtitle}>EASY, SIMPLE, FREE</p>
        <h2 className={styles.title}>
          Why Choose AdaKita <br /> for Your Personal Loans Needs?
        </h2>
        <p className={styles.caption}>
          There’s no such thing as too many questions
        </p>

        <div className={styles.cards}>
          <InfoCard
            icon={<span>🤝</span>}
            title="Find a Loan from Reputable Lenders in Minutes"
            description="Whether you're seeking to consolidate debt or address an unexpected financial need, Clear Credit AI simplifies the process of finding a personal loan tailored to your unique circumstances."
            buttonText="Learn more"
            buttonAction= { () => { alert("Info Card 1 clicked!"); } }
          />
          <InfoCard
            icon={<span>🛡️</span>}
            title="Your Data Is Safe & Secure"
            description="Your privacy matters to us. Rest assured that it’s 100% free, and your data is never shared or sold to lenders. Your financial information remains confidential and secure."
            buttonText="Learn more"
            buttonAction= { () => { alert("Info Card 2 clicked!"); } }
          />
          <InfoCard
            icon={<span>🔍</span>}
            title="We Are Unbiased and Transparent"
            description="We don't play favorites or accept payments to promote specific loan products. You'll always have a clear understanding of the costs involved, with no hidden fees or surprises."
            buttonText="Learn more"
            buttonAction= { () => { alert("Info Card 3 clicked!"); } }
          />
        </div>

      </section>
    </GradientContainer>

  );
};

export default CTABanner;
