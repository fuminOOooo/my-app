import React from "react";
import styles from "./InfoCard.module.css";

interface InfoCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  buttonText: string;
  buttonAction: () => void;
}

const InfoCard: React.FC<InfoCardProps> = ({ icon, title, description, buttonText, buttonAction }) => {
  return (
    <div className={styles.card}>
      <div className={styles.iconWrapper}>{icon}</div>
      <h3 className={styles.title}>{title}</h3>
      <p className={styles.description}>{description}</p>
      <button 
        className={styles.button}
        onClick={buttonAction}
      >
        {buttonText}<span className={styles.arrow}>→</span>
      </button>
    </div>
  );
};

export default InfoCard;
