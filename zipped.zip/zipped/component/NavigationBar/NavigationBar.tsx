import React, { useState } from "react";
import styles from "./NavigationBar.module.css";
import FilledActionButton from "../FilledActionButton/FilledActionButton";

interface NavigationBarProps {
  logo: React.ReactNode;
  auth: React.ReactNode;
  links: React.ReactNode;
}

const NavigationBar = ({ logo, links, auth }:NavigationBarProps) => {

  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className={styles.navbar}>
      <div className={styles.container}>
        <div className={styles.innerContainer}>
          
          <div className={styles.logo}>{logo}</div>
          
          <div className={`${styles.links} ${styles.desktopMenu}`}>{links}</div>

          <div className={`${styles.auth} ${styles.desktopMenu}`}>{auth}</div>

          <div className={styles.mobileMenuButton}>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className={styles.hamburger}
            >
              {isOpen ? (
                <span className={styles.closeIcon}>&#10005;</span>
              ) : (
                <span className={styles.hamburgerIcon}>&#9776;</span>
              )}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className={styles.mobileDropdown}>
          <div className={styles.mobileItems}>
            {links}
            {auth}
          </div>
        </div>
      )}
    </nav>
  );
  
};

const GuessNavigationBar = () => {
  
  return <NavigationBar

    logo={<span>AdaKami</span>}

    links={
      <>
        <a href="/" className={styles.link}>Home</a>
        <a href="/compare" className={styles.link}>Compare Lenders</a>
        <a href="/calculator" className={styles.link}>Saving Calculator</a>
        <a href="/blogs" className={styles.link}>Blogs</a>
        <a href="/contact" className={styles.link}>Contact Us</a>
      </>
    }
    
    auth={
      <div className={styles.authButtons}>
        <a href="/login" className={styles.unfilledButton}>Login</a>
        <FilledActionButton text="Register Now" onClick={()=>{}} />
      </div>
    }

  />;

};

export default GuessNavigationBar;
