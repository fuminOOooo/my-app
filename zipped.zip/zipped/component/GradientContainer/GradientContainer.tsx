import styles from './GradientContainer.module.css';

interface GradientContainerProps {
  children: React.ReactNode;
}

export default function GradientContainer({ children }: GradientContainerProps) {
  return (
    <div className={styles.background}>
      {children}
    </div>
  );
}